$(document).ready(function () {
  $(".fa-search").click(function () {
    $(".search-box").toggle();
    $("#menu-search").focus();
  });
});

// --- Live Time start---//
$(document).ready(function () {
  clockUpdate();
  setInterval(clockUpdate, 1000);
});

function clockUpdate() {
  var date = new Date();
  $(".digital-clock").css({ color: "#fff", "text-shadow": "0 0 6px #ff0" });
  function addZero(x) {
    if (x < 10) {
      return (x = "0" + x);
    } else {
      return x;
    }
  }

  function twelveHour(x) {
    if (x > 12) {
      return (x = x - 12);
    } else if (x == 0) {
      return (x = 12);
    } else {
      return x;
    }
  }

  var h = addZero(twelveHour(date.getHours()));
  var m = addZero(date.getMinutes());
  var s = addZero(date.getSeconds());

  $(".digital-clock").text(h + ":" + m + ":" + s);
}
//----- Live time end-----//

// search-city
$(document).ready(function () {
  $("#searchbtn").click(function (e) {
    // e.preventDefault();
    var city = $("#city").val().trim();
    $("#search-form").trigger("reset");
    if (city != "") {
      $.ajax({
        url:
          "http://api.openweathermap.org/data/2.5/weather?q=" +
          city +
          "&units=metric" +
          "&appid=558a1768f3ab19e80c73b31dba6c4b48",
        type: "GET",
        dataType: "json",
        success: function (data) {
          console.log(data);
          updateWeather(data);
        },
      });
    } else {
      $("#error").html("field cannot be empty");
    }
  });
});
//Checking for day or night card-image
const isDayTime = (icon) => {
  if (icon.includes("d")) {
    return true;
  } else {
    return false;
  }
};

// updatecard

updateWeather = (city) => {
  const imgName = city.weather[0].icon;
  const iconSrc = `https://openweathermap.org/img/wn/${imgName}@2x.png`;
  $(".ct-nm-head").html(city.name);
  $(".card-body").html(
    `<div class="card-body">
    <div class="card-mid row">
      <div class="col-8 text-center temp">
        <span>${Math.trunc(city.main.temp)}&deg;C</span>
      </div>
      <div class="col-4 condition-temp">
        <p class="condition">${city.weather[0].main}</p>
        <p class="high">${Math.trunc(city.main.temp_max)}&deg;C</p>
        <p class="low">${Math.trunc(city.main.temp_min)}&deg;C</p>
      </div>
    </div>
    <div class="icon-container card shadow mx-auto">
      <img src="${iconSrc}" alt="cloud" />
    </div>
    <div class="card-bottom px-5 py-4 row">
      <div class="col text-center">
      <p>${Math.trunc(city.main.feels_like)}&deg;C</p>
        <span>Feels Like</span>
      </div>
      <div class="col text-center">
        <p>${city.main.humidity}%</p>
        <span>Humidity</span>
      </div>
    </div>
  </div>`
  );
  if (isDayTime(imgName)) {
    console.log('day');
    $('.time').attr('src', 'img/day_image.svg');
    if($('.ct-nm-head').hasClass('text-white')){
      $('.ct-nm-head').removeClass('text-white');
    }else{
      $('.ct-nm-head').addClass('text-black');
    }
  } else {
    console.log('night');
    $('.time').attr('src', 'img/night_image.svg');
    if($('.ct-nm-head').hasClass('text-black')){
      $('.ct-nm-head').removeClass('text-black');
    }else{
      $('.ct-nm-head').addClass('text-white');
    }
  }
  $('.card').removeClass('d-none');
};
