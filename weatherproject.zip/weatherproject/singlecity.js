$(document).ready(function () {
   
    // e.preventDefault();

    $.ajax({
      url:
        "http://api.openweathermap.org/data/2.5/weather?q=pune" +
        "&units=metric" +
        "&appid=558a1768f3ab19e80c73b31dba6c4b48",
      type: "GET",
      dataType: "json",
      success: function (data) {
        console.log(data);
        updatePuneWeather(data);
      },
    });
  });

 
  // updatecard
  
  updatePuneWeather = (city) => {
    const imgName = city.weather[0].icon;
    const iconSrc = `https://openweathermap.org/img/wn/${imgName}@2x.png`;
    $(".ctp-nm-head").html("Pune");
    $(".pune-card-body").html(
      `<div class="card-body">
      <div class="card-mid row">
        <div class="col-8 text-center temp">
          <span>${Math.trunc(city.main.temp)}&deg;C</span>
        </div>
        <div class="col-4 condition-temp">
          <p class="condition">${city.weather[0].main}</p>
          <p class="high">${Math.trunc(city.main.temp_max)}&deg;C</p>
          <p class="low">${Math.trunc(city.main.temp_min)}&deg;C</p>
        </div>
      </div>
      <div class="icon-container card shadow mx-auto">
        <img src="${iconSrc}" alt="cloud" />
      </div>
      <div class="card-bottom px-5 py-4 row">
        <div class="col text-center">
        <p>${Math.trunc(city.main.feels_like)}&deg;C</p>
          <span>Feels Like</span>
        </div>
        <div class="col text-center">
          <p>${city.main.humidity}%</p>
          <span>Humidity</span>
        </div>
      </div>
    </div>`
    );
    if (pisDayTime(imgName)) {
      console.log('day');
      $('.time').attr('src', 'img/day_image.svg');
      if($('.ct-nm-head').hasClass('text-white')){
        $('.ct-nm-head').removeClass('text-white');
      }else{
        $('.ct-nm-head').addClass('text-black');
      }
    } else {
      console.log('night');
      $('.time').attr('src', 'img/night_image.svg');
      if($('.ct-nm-head').hasClass('text-black')){
        $('.ct-nm-head').removeClass('text-black');
      }else{
        $('.ct-nm-head').addClass('text-white');
      }
    }
};


// Gandhinagar data-------------

$(document).ready(function () {
  
    // e.preventDefault();

    $.ajax({
      url:
        "http://api.openweathermap.org/data/2.5/weather?q=gandhinagar" +
        "&units=metric" +
        "&appid=558a1768f3ab19e80c73b31dba6c4b48",
      type: "GET",
      dataType: "json",
      success: function (data) {
        console.log(data);
        updateGnrWeather(data);
      },
    });
  });

  // updatecard
  
  updateGnrWeather = (city) => {
    const imgName = city.weather[0].icon;
    const iconSrc = `https://openweathermap.org/img/wn/${imgName}@2x.png`;
    $(".ctg-nm-head").html("Gandhinagar");
    $(".gnr-card-body").html(
      `<div class="card-body">
      <div class="card-mid row">
        <div class="col-8 text-center temp">
          <span>${Math.trunc(city.main.temp)}&deg;C</span>
        </div>
        <div class="col-4 condition-temp">
          <p class="condition">${city.weather[0].main}</p>
          <p class="high">${Math.trunc(city.main.temp_max)}&deg;C</p>
          <p class="low">${Math.trunc(city.main.temp_min)}&deg;C</p>
        </div>
      </div>
      <div class="icon-container card shadow mx-auto">
        <img src="${iconSrc}" alt="cloud" />
      </div>
      <div class="card-bottom px-5 py-4 row">
        <div class="col text-center">
        <p>${Math.trunc(city.main.feels_like)}&deg;C</p>
          <span>Feels Like</span>
        </div>
        <div class="col text-center">
          <p>${city.main.humidity}%</p>
          <span>Humidity</span>
        </div>
      </div>
    </div>`
    );
    if (isDayTime(imgName)) {
      console.log('day');
      $('.time').attr('src', 'img/day_image.svg');
      if($('.ct-nm-head').hasClass('text-white')){
        $('.ct-nm-head').removeClass('text-white');
      }else{
        $('.ct-nm-head').addClass('text-black');
      }
    } else {
      console.log('night');
      $('.time').attr('src', 'img/night_image.svg');
      if($('.ct-nm-head').hasClass('text-black')){
        $('.ct-nm-head').removeClass('text-black');
      }else{
        $('.ct-nm-head').addClass('text-white');
      }
    }
};
// New York-------
$(document).ready(function () {
  
    // e.preventDefault();

    $.ajax({
      url:
        "http://api.openweathermap.org/data/2.5/weather?q=new york" +
        "&units=metric" +
        "&appid=558a1768f3ab19e80c73b31dba6c4b48",
      type: "GET",
      dataType: "json",
      success: function (data) {
        console.log(data);
        updateNwWeather(data);
      },
    });
  });

  // updatecard
  
  updateNwWeather = (city) => {
    const nwimgName = city.weather[0].icon;
    const iconSrc = `https://openweathermap.org/img/wn/${nwimgName}@2x.png`;
    $(".ctn-nm-head").html("New York");
    $(".nw-card-body").html(
      `<div class="card-body">
      <div class="card-mid row">
        <div class="col-8 text-center temp">
          <span>${Math.trunc(city.main.temp)}&deg;C</span>
        </div>
        <div class="col-4 condition-temp">
          <p class="condition">${city.weather[0].main}</p>
          <p class="high">${Math.trunc(city.main.temp_max)}&deg;C</p>
          <p class="low">${Math.trunc(city.main.temp_min)}&deg;C</p>
        </div>
      </div>
      <div class="icon-container card shadow mx-auto">
        <img src="${iconSrc}" alt="cloud" />
      </div>
      <div class="card-bottom px-5 py-4 row">
        <div class="col text-center">
        <p>${Math.trunc(city.main.feels_like)}&deg;C</p>
          <span>Feels Like</span>
        </div>
        <div class="col text-center">
          <p>${city.main.humidity}%</p>
          <span>Humidity</span>
        </div>
      </div>
    </div>`
    );
    if (nisDayTime(nwimgName)) {
      console.log('day');
      $('.time').attr('src', 'img/day_image.svg');
      if($('.ct-nm-head').hasClass('text-white')){
        $('.ct-nm-head').removeClass('text-white');
      }else{
        $('.ct-nm-head').addClass('text-black');
      }
    } else {
      console.log('night');
      $('.time').attr('src', 'img/night_image.svg');
      if($('.ct-nm-head').hasClass('text-black')){
        $('.ct-nm-head').removeClass('text-black');
      }else{
        $('.ct-nm-head').addClass('text-white');
      }
    }
};


const pisDayTime = (icon) => {
    if (icon.includes("d")) {
      return true;
    } else {
      return false;
    }
  };

  const nisDayTime = (icon) => {
    if (icon.includes("d")) {
      return true;
    } else {
      return false;
    }
  };